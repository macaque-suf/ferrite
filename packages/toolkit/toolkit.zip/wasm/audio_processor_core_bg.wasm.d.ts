/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_noisereducer_free: (a: number, b: number) => void;
export const greet: (a: number, b: number, c: number) => void;
export const noisereducer_frame_size: (a: number) => number;
export const noisereducer_learn_noise: (a: number, b: number, c: number) => void;
export const noisereducer_new: (a: number) => number;
export const noisereducer_process: (a: number, b: number, c: number, d: number) => void;
export const noisereducer_reset: (a: number) => void;
export const noisereducer_sample_rate: (a: number) => number;
export const noisereducer_set_bypass: (a: number, b: number) => void;
export const noisereducer_set_gate_enabled: (a: number, b: number) => void;
export const noisereducer_set_gate_threshold: (a: number, b: number) => void;
export const noisereducer_set_reduction_amount: (a: number, b: number) => void;
export const noisereducer_set_spectral_enabled: (a: number, b: number) => void;
export const noisereducer_set_wiener_filter_mode: (a: number, b: number) => void;
export const __wbindgen_export_0: (a: number, b: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export_1: (a: number, b: number, c: number) => void;
export const __wbindgen_export_2: (a: number, b: number, c: number, d: number) => number;
