/**
 * Mock WASM module for testing without actual Rust compilation
 * This simulates the WASM audio processor interface
 */

// Mock WASM initialization
export default async function init(): Promise<void> {
  // Simulate WASM loading delay
  await new Promise(resolve => setTimeout(resolve, 100));
  console.log('[MOCK WASM] Module initialized');
}

/**
 * Mock NoiseReducer class that simulates WASM audio processing
 */
export class NoiseReducer {
  private sampleRate: number;
  private gateEnabled = true;
  private spectralEnabled = true;
  private gateThreshold = -40;
  private oversubtractionFactor = 2.0;
  private spectralFloor = 0.1;
  private noiseProfile: Float32Array | null = null;
  private profileFrozen = false;
  private simdEnabled = false;
  
  // Mock memory tracking
  private memoryUsed = 0;
  private memoryPeak = 0;
  private readonly memoryTotal = 1024 * 1024 * 16; // 16MB
  
  constructor(sampleRate: number) {
    this.sampleRate = sampleRate;
    this.memoryUsed = 1024 * 100; // 100KB initial
    this.memoryPeak = this.memoryUsed;
  }
  
  /**
   * Process audio data
   */
  process(input: Float32Array): Float32Array {
    const output = new Float32Array(input.length);
    
    // Simple mock processing: apply gate and slight filtering
    for (let i = 0; i < input.length; i++) {
      let sample = input[i];
      
      // Mock gate processing
      if (this.gateEnabled) {
        const amplitude = Math.abs(sample);
        const thresholdLinear = Math.pow(10, this.gateThreshold / 20);
        
        if (amplitude < thresholdLinear) {
          sample *= 0.1; // Reduce by 20dB
        }
      }
      
      // Mock spectral processing (simple high-pass filter)
      if (this.spectralEnabled && i > 0) {
        sample = sample - input[i - 1] * 0.3;
      }
      
      // Apply some noise reduction simulation
      if (this.noiseProfile && !this.profileFrozen) {
        const noiseLevel = this.noiseProfile[i % this.noiseProfile.length];
        sample *= (1 - noiseLevel * this.oversubtractionFactor * 0.1);
      }
      
      output[i] = sample * 0.9; // Slight volume reduction
    }
    
    // Update memory tracking
    this.memoryUsed += input.length * 4;
    this.memoryPeak = Math.max(this.memoryPeak, this.memoryUsed);
    
    return output;
  }
  
  /**
   * Configuration setters - note the underscore naming convention for WASM compatibility
   */
  set_gate_enabled(enabled: boolean): void {
    this.gateEnabled = enabled;
  }
  
  set_gate_threshold(threshold: number): void {
    this.gateThreshold = threshold;
  }
  
  set_spectral_enabled(enabled: boolean): void {
    this.spectralEnabled = enabled;
  }
  
  set_oversubtraction_factor(factor: number): void {
    this.oversubtractionFactor = factor;
  }
  
  set_spectral_floor(floor: number): void {
    this.spectralFloor = floor;
  }
  
  set_simd_enabled(enabled: boolean): void {
    this.simdEnabled = enabled;
  }
  
  /**
   * Noise profile management
   */
  learn_noise_profile(samples: Float32Array): void {
    // Simple mock: just store the spectrum
    this.noiseProfile = new Float32Array(samples);
  }
  
  set_noise_profile(profile: Float32Array): void {
    this.noiseProfile = new Float32Array(profile);
  }
  
  freeze_noise_profile(): void {
    this.profileFrozen = true;
  }
  
  unfreeze_noise_profile(): void {
    this.profileFrozen = false;
  }
  
  reset_noise_profile(): void {
    this.noiseProfile = null;
    this.profileFrozen = false;
  }
  
  /**
   * Memory management
   */
  allocate(size: number): number {
    this.memoryUsed += size;
    this.memoryPeak = Math.max(this.memoryPeak, this.memoryUsed);
    // Return mock pointer
    return Math.floor(Math.random() * 0xFFFFFF);
  }
  
  deallocate(ptr: number): void {
    // Mock deallocation
    this.memoryUsed = Math.max(0, this.memoryUsed - 1024);
  }
  
  get_memory_used(): number {
    return this.memoryUsed;
  }
  
  get_memory_total(): number {
    return this.memoryTotal;
  }
  
  get_memory_peak(): number {
    return this.memoryPeak;
  }
  
  /**
   * Reset the processor
   */
  reset(): void {
    this.gateEnabled = true;
    this.spectralEnabled = true;
    this.gateThreshold = -40;
    this.oversubtractionFactor = 2.0;
    this.spectralFloor = 0.1;
    this.noiseProfile = null;
    this.profileFrozen = false;
  }
  
  /**
   * Free resources
   */
  free(): void {
    this.noiseProfile = null;
    this.memoryUsed = 0;
    console.log('[MOCK WASM] NoiseReducer freed');
  }
}

/**
 * Mock utilities for testing
 */
export function mockProcessAudio(input: Float32Array): Float32Array {
  // Simple pass-through with slight modification
  const output = new Float32Array(input.length);
  for (let i = 0; i < input.length; i++) {
    output[i] = input[i] * 0.95;
  }
  return output;
}

export function mockGetVersion(): string {
  return "1.0.0-mock";
}

export function mockGetSampleRate(): number {
  return 48000;
}